<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class COUPON extends Model
{
    //
}
