<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class product_color extends Model
{
    //
}
